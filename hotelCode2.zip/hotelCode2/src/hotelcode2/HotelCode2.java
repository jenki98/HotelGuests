package hotelcode2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.FileReader;
import java.io.IOException;

public class HotelCode2 {

    public static void main(String[] args) throws IOException {

        Scanner in = new Scanner(System.in);
        Room[] myHotel = new Room[12];
        for (int i = 0; i < myHotel.length; i++) {
            myHotel[i] = new Room();

        }
        initialise(myHotel);
        String choice;

        do {
            System.out.println("Please choose one of the following options:");
            System.out.println("A : Add customer in a room");
            System.out.println("V : View hotel rooms");
            System.out.println("E : Display Empty rooms");
            System.out.println("D : Delete customer from room");
            System.out.println("F : Find room from customer name");
            System.out.println("S : Store program data in to the file ");
            System.out.println("L : Load program data from file");
            System.out.println("O : View rooms Ordered alphabetically by name");
            System.out.println("X : Exit");

            choice = in.next().toUpperCase();

            switch (choice) {
                case "A":
                    addCustomer(myHotel, in);
                    break;
                case "V":
                    viewRooms(myHotel);
                    break;
                case "E":
                    emptyRooms(myHotel);
                    break;
                case "D":
                    deleteCustomer(myHotel, in);
                    break;
                case "F":
                    findRoom(myHotel, in);
                    break;
                case "S":
                    storeData(myHotel);
                    break;
                case "L":
                    loadData(myHotel);
                    break;
                case "O":
                    orderedView(myHotel);
                    break;
                case "X":
                    System.exit(0);
            }
        } while (!choice.equals("x"));

    }

    private static void initialise(Room hotelRef[]) {
        for (int x = 0; x < 12; x++) {
            hotelRef[x].mainName = "e";

        }

    }

    private static void addCustomer(Room hotelRef[], Scanner in) {
        String roomName;
        int roomNum = 0;
        System.out.println("Enter room number from 0 - 11");
        while (!in.hasNextInt()) { // integer validation
            System.out.println("INVALID INPUT: ENTER A ROOM NUMBER FROM 0 - 11");
            in.next();
        }

        roomNum = in.nextInt();
        while (roomNum > 11) { // range validation
            System.out.println("Out of range! Enter a room number from 0 - 11");
            roomNum = in.nextInt();
        }
        System.out.println("Enter name for room " + roomNum + ":");
        roomName = in.next().toUpperCase();
        hotelRef[roomNum].mainName = roomName;

    }

    private static void viewRooms(Room hotelRef[]) {

        for (int x = 0; x < hotelRef.length; x++) {
            if (!hotelRef[x].mainName.equals("e")) {
                System.out.println("room " + x + " occupied by " + hotelRef[x].mainName);
            } else {
                System.out.println("room " + x + " is empty");
            }
        }

    }

    private static void emptyRooms(Room hotelRef[]) {
        for (int i = 0; i < hotelRef.length; i++) {
            if (hotelRef[i].mainName.equals("e")) {
                System.out.println("room " + i + " is empty");
            }

        }
    }

    private static void deleteCustomer(Room hotelRef[], Scanner in) {
        System.out.println("Enter customer to delete");
        String customer = in.next().toUpperCase();
        for (int i = 0; i < hotelRef.length; i++) {
            if (hotelRef[i].mainName.equals(customer)) {
                hotelRef[i].mainName = "e";
                break;
            }

        }

    }

    private static void findRoom(Room hotelRef[], Scanner in) {
        String name;
        System.out.println("Enter Name");
        name = in.next().toUpperCase();
        for (int i = 0; i < hotelRef.length; i++) {
            if (hotelRef[i].mainName.equals(name)) {
                System.out.println(name + " " + "is in room " + i);
                break;
            }
            if (!hotelRef[i].mainName.equals(name)) {
                System.out.println("Customer not found");

            }

        }
    }

    private static void storeData(Room hotelRef[]) throws IOException {
        BufferedWriter outputWriter;
        outputWriter = null;

        outputWriter = new BufferedWriter(new FileWriter("myFile1.txt"));
        for (int i = 0; i < hotelRef.length; i++) {
            outputWriter.write(hotelRef[i].getName() + "");
            outputWriter.newLine();
        }
        outputWriter.flush();
        outputWriter.close();

    }

    private static void loadData(Room hotelRef[]) throws IOException {
        int lineCount = 0;
        try (Scanner rf = new Scanner(new BufferedReader(new FileReader("C:\\Users\\uzuma\\Documents\\Programming principles 2 assignment 1\\hotelCode2\\myFile1.txt")))) {
            String fileLine;
            while (rf.hasNext()) {
                fileLine = rf.nextLine();
                hotelRef[lineCount].setName(fileLine);
                System.out.println(lineCount + "  " + fileLine);
                lineCount++;

            }
        } catch (IOException e) {
            System.out.println("Error IOException is: " + e);
        }

    }

    private static void orderedView(Room hotelRef[]) {
        for (int i = 0; i < hotelRef.length; i++) {
            for (int j = i + 1; j < hotelRef.length; j++) {
                if (((hotelRef[i].getName()).compareTo((hotelRef[j].getName()))) > 0) {
                    Room temp = hotelRef[i];
                    hotelRef[i] = hotelRef[j];
                    hotelRef[j] = temp;
                }
            }
        }
        System.out.print("Names in Sorted Order:");
        for (int i = 0; i < hotelRef.length - 1; i++) {
            System.out.println(hotelRef[i].getName() + " ");

        }

    }

}
