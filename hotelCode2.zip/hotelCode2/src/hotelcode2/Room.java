/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelcode2;


public class Room {
    String mainName;
    int guestsInRoom;
    
    public Room(){
        mainName = "k";
        System.out.println("made a room ");
    }
    public void setName(String aName){
        mainName = aName;
    }
    public String getName(){
        return mainName;
    }

    public int compareTo(Room room) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
